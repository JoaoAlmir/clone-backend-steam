package br.ufc.quixada.dao.jpa;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import br.ufc.quixada.dao.ProgressDAO;
import br.ufc.quixada.entity.Progress;

@Repository
public interface ProgressJPADAO extends ProgressDAO, JpaRepository<Progress, String> {

  // NamedQuery
  @Query(name = "getCompleteProgress")
  public List<Progress> findByProgressPercent();

  // NativeQuery
  @Query(value = "select * from progress where trophyQuantity = 0", nativeQuery = true)
  public List<Progress> findByTrophyQuantity();

  // NativeQuery
  @Query(value = "select * from progress where idProfile = :id", nativeQuery = true)
  public List<Progress> findByProfile(String id);

  // NativeQuery
  @Query(value = "select * from progress where idGame = :id", nativeQuery = true)
  public List<Progress> findByGame(String id);

  // NativeQuery
  @Query(value = "select * from progress where minutesPlayed >= :minutes", nativeQuery = true)
  public List<Progress> findByMinutesPlayed(Integer minutes);
}